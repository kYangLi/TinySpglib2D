# Developer document

```{toctree}
   :maxdepth: 1

   Magnetic space group <magnetic_spacegroup>
   Flags to control action of magnetic symmetry operations <magnetic_symmetry_flags>
```
